scoreboard players add $tiempo ticks 1

execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount1=15..}] at @s run advancement grant @s only luistercorp:earthblade/discos/earthblade_todos_casi
execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount2=9..}] at @s run advancement grant @s only luistercorp:earthblade/structuras/earthblade_todas_structuras
execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount3=13..}] at @s run advancement grant @s only luistercorp:earthblade/discos/earthblade_todos_todos
execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount1=1..}] at @s run advancement grant @s only luistercorp:adventure/earthblade
execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount2=1..}] at @s run advancement grant @s only luistercorp:adventure/earthblade
execute if score $tiempo ticks matches 20.. as @a[scores={earthbladecount3=1..}] at @s run advancement grant @s only luistercorp:adventure/earthblade

execute if score $tiempo ticks matches 20.. run effect give @a[nbt={equipment:{offhand:{id:"minecraft:echo_shard",components:{"minecraft:custom_model_data":{strings:["cumulo_fragmento_eco"]}}}}}] invisibility 5 0 false 
execute if score $tiempo ticks matches 20.. run effect give @a[nbt={SelectedItem:{id:"minecraft:echo_shard",components:{"minecraft:custom_model_data":{strings:["cumulo_fragmento_eco"]}}}}] invisibility 5 0 false 

execute if score $tiempo ticks matches 20.. as @e[tag=childof] run tag @s add childof_leido
execute if score $tiempo ticks matches 20.. as @e[tag=childof] run tag @s remove childof
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=..10] run effect give @s haste 10 2
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=10..15] run effect give @s haste 10 1
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=15..20] run effect give @s haste 10 0
execute if score $tiempo ticks matches 20.. as @e[tag=childof_leido] at @s unless block ~ ~-1.1 ~ jukebox{RecordItem:{id:"minecraft:music_disc_13"}} run kill @s

execute if score $tiempo ticks matches 20.. as @e[tag=childof] run tag @s add childof_leido
execute if score $tiempo ticks matches 20.. as @e[tag=childof] run tag @s remove childof
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=..10] run effect give @s haste 10 2
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=10..15] run effect give @s haste 10 1
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=childof_leido,distance=15..20] run effect give @s haste 10 0
execute if score $tiempo ticks matches 20.. as @e[tag=childof_leido] at @s unless block ~ ~-1.1 ~ jukebox{RecordItem:{id:"minecraft:music_disc_13",components:{"minecraft:jukebox_playable":"luistercorp:earthblade/childof"}}} run kill @s

execute if score $tiempo ticks matches 20.. as @e[tag=defy] run tag @s add defy_leido
execute if score $tiempo ticks matches 20.. as @e[tag=defy] run tag @s remove defy
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=defy_leido,distance=..10] run effect give @s water_breathing 10 2
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=defy_leido,distance=10..15] run effect give @s water_breathing 10 1
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=defy_leido,distance=15..20] run effect give @s water_breathing 10 0
execute if score $tiempo ticks matches 20.. as @e[tag=defy_leido] at @s unless block ~ ~-1.1 ~ jukebox{RecordItem:{id:"minecraft:music_disc_13",components:{"minecraft:jukebox_playable":"luistercorp:earthblade/defy"}}} run kill @s

execute if score $tiempo ticks matches 20.. as @e[tag=depose] run tag @s add depose_leido
execute if score $tiempo ticks matches 20.. as @e[tag=depose] run tag @s remove depose
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=depose_leido,distance=..10] run effect give @s strength 10 2
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=depose_leido,distance=10..15] run effect give @s strength 10 1
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=depose_leido,distance=15..20] run effect give @s strength 10 0
execute if score $tiempo ticks matches 20.. as @e[tag=depose_leido] at @s unless block ~ ~-1.1 ~ jukebox{RecordItem:{id:"minecraft:music_disc_13",components:{"minecraft:jukebox_playable":"luistercorp:earthblade/depose"}}} run kill @s

execute if score $tiempo ticks matches 20.. as @e[tag=reflection] run tag @s add reflection_leido
execute if score $tiempo ticks matches 20.. as @e[tag=reflection] run tag @s remove reflection
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=reflection_leido,distance=..10] run effect give @s regeneration 10 2
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=reflection_leido,distance=10..15] run effect give @s regeneration 10 1
execute if score $tiempo ticks matches 20.. as @a at @s if entity @e[tag=reflection_leido,distance=15..20] run effect give @s regeneration 10 0
execute if score $tiempo ticks matches 20.. as @e[tag=reflection_leido] at @s unless block ~ ~-1.1 ~ jukebox{RecordItem:{id:"minecraft:music_disc_13",components:{"minecraft:jukebox_playable":"luistercorp:earthblade/reflection"}}} run kill @s

execute if score $tiempo ticks matches 20.. run scoreboard players set $tiempo ticks 0

