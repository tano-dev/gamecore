advancement revoke @a only luistercorp:function/totem_explosivo
execute as @s at @s run tag @e[distance=..4] add cerca
execute as @e at @s[tag=cerca] run damage @s 5 explosion by @p
execute as @e at @s[tag=cerca] run particle explosion ~ ~ ~ 0.5 0.5 0.5 0 5
execute as @e at @s[tag=cerca] run particle explosion_emitter ~ ~ ~ 0.5 0.5 0.5 0 1
execute as @e at @s[tag=cerca] run particle smoke ~ ~ ~ 0.5 0.5 0.5 0 10


schedule function luistercorp:quitartag 1s

