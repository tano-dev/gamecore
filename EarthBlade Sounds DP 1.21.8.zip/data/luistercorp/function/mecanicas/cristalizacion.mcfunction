execute store result score @s random run random value 1..4
execute if score @s random matches 1 run effect give @s resistance 70 3
execute if score @s random matches 1 run title @s title {"translate": "luistercorp.earthblade.mensaje.cristalizacion","italic": false,"color": "#d8a6ff"}
advancement revoke @s only luistercorp:function/pastel_amatista
