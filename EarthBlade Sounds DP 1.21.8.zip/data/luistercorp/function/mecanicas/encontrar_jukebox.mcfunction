execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ jukebox{RecordItem:{id:"minecraft:music_disc_13"}} run scoreboard players add @s encontro 1
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ jukebox{RecordItem:{id:"minecraft:music_disc_13"}} run function luistercorp:mecanicas/colocar_disc_magic
scoreboard players remove @s vector 1
execute unless score @s encontro matches 1.. if score @s vector matches 1.. positioned ^ ^ ^0.5 run function luistercorp:mecanicas/encontrar_jukebox
