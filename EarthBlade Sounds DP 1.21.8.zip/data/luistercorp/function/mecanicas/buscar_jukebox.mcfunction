scoreboard players set @s vector 8
scoreboard players set @s encontro 0
execute anchored eyes positioned ^ ^ ^ run function luistercorp:mecanicas/encontrar_jukebox

advancement revoke @s only luistercorp:mecanicas/disco_colocado